//checkbox
$("input.custom-checkbox").after("<span class='checkbox-wrapper'></span>")

//sidebar
function sideBar(){
	if ($(window).width() >= 960) {
	   $("#checkbox1").prop('checked', true);
	   if ($(window).width() > 1024) {
		  if ($('#checkbox1:checked').length > 0) {    
				var offset = $(".sidebar").offset();
				var topPadding = 15;
				$(window).scroll(function() {
					if ($(window).scrollTop() > offset.top) {
						$(".sidebar").stop().animate({
							marginTop: $(window).scrollTop() - offset.top + topPadding
						});
					} else {
						$(".sidebar").stop().animate({
							marginTop: 0
						});
					};
				});
			}else{
				$(".sidebar").addClass("no-offset");
			}	 
		}	   
			
		$('#checkbox1').click(function(){
			if ($('#checkbox1:checked').length > 0) {
				$(".sidebar.no-offset").removeClass("no-offset");		
				$(".sidebar.all-collaps .sidebar-nav-inner").slideUp(200);
				$(".sidebar.all-collaps .sidebar-nav-inner").parents("li").removeClass("active");		
				setTimeout(function(){
					$(".sidebar.all-collaps").removeClass("all-collaps");	
				}, 1000);
			}else{
			$(".sidebar").addClass("no-offset");
			}
		}) 
		$(window).scroll(function() {
		   if($(window).scrollTop() + $(window).height() == $(document).height()) {
			   $(".sidebar").addClass("bottom-scrolled");
		   }
		   else{
			 $(".sidebar").removeClass("bottom-scrolled");   
		   }
		});		
	}
	else{
		$(".sidebar-toggle").click(function(e){
			e.preventDefault();
			$(this).toggleClass("side-bar-active");
			$("body").toggleClass("sidebar-open");
			$(".static-sidebar-wrapper").toggleClass("sidebar-open");
		});
	}
}
function sideBarDistroy(){
	$("body").removeClass("sidebar-open");
    $(".sidebar-toggle").removeClass("side-bar-active");
	$(".static-sidebar-wrapper").removeClass("sidebar-open");
	
};
//sidebar active state
function secondaryNav(index){
 var allLinks=$('.sidebar-nav > li');
 allLinks.removeClass('active');
 allLinks.find("ul").slideUp();
 $(allLinks[index-1]).addClass('active');
 $(allLinks[index-1]).find("ul").slideDown();
}
function secondaryNavInternal(index){
	var allLinks=$('.active .sidebar-nav-inner > li ');
	 allLinks.removeClass('active');
	 $(allLinks[index-1]).addClass('active');
}

// all collaps
$(document).ready(function(e) {
	$(".open-close-toggle button:last").prop('disabled', true);
    $(".sidebar-nav li a span.button-side").click(function(e){
		e.preventDefault();
		e.stopPropagation();
		$(this).parent("a").next("ul").slideToggle(200);
		$(this).parents("li").toggleClass("active");
		if ($(".sidebar-nav li.active").length < 0 ){
			$(".sidebar").removeClass("all-collaps");
		}
	});
	$(".open-close-toggle button:first").click(function(){
		$(".sidebar-nav-inner").slideDown(200);
		$(".sidebar-nav-inner").parents("li").addClass("active");
		$(".sidebar").addClass("all-collaps");
		$("#checkbox1").prop('checked', false);
		$(".open-close-toggle button:last").prop('disabled', false);
	});
	$(".open-close-toggle button:last").click(function(){	
		$(this).prop('disabled', true);	
		$(".sidebar-nav-inner").slideUp(200);
		$(".sidebar-nav-inner").parents("li").removeClass("active");
		$(".sidebar").removeClass("all-collaps").addClass("no-offset");
		if($(".sidebar.no-offset").length > 0 ){
			$("#checkbox1").prop('checked', false);	   
		}
		
	});
});
//tooltip
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
//info bar equal height
function infoBar(){
    var infoBarHeight =  $(".data-list").height();
	$(".infobar-toggle-wrapper").height(infoBarHeight);
};
//info bar toggle
$(".infobar-toggle-wrapper a.btn-toggle").click(function(e){
	e.preventDefault();
	$(this).parents(".infobar-wrapper").toggleClass("toggle-open");
});
// block-data div equal height
function blockDataHeight(){
	if ($(window).width() > 767) {
		$('.infobar-bottom').each(function(){  
			 var $columns = $('.info-block',this);
			 var maxHeight = Math.max.apply(Math, $columns.map(function(){
				 return $(this).height();
			 }).get());
			 $columns.height(maxHeight);
		});
	}
	else{
		$('.info-block').css("height","auto");
		}
};
//collapse panel
$(".panel-heading").click(function(e){
	e.preventDefault();
	$(this).next(".panel-collapse").slideToggle();
	$(this).parent(".panel").toggleClass("active");
	
});
//collapse panel button event
$('.panel-heading').click(function () {
          myFunction(this);
});
function myFunction(element) {
    console.log(element.id);
}
//
$(window).on("load",function() {	
	infoBar();
	blockDataHeight();
});
$(document).ready(function() {
    sideBar();
	sideBarDistroy();
});
$(window).resize(function() {
	sideBarDistroy();
	sideBar();
	infoBar();
	blockDataHeight();
});

//Datepicker
$(function () {
	$('.date').datetimepicker({
		useCurrent: false,	
		icons: {
			time: "mdi mdi-clock",
			date: "mdi mdi-calendar",
			up: "mdi mdi-chevron-up",
			down: "mdi mdi-chevron-down",
			right:"mdi mdi-chevron-right",
			left:"mdi mdi-chevron-left"
		},
		format: 'MM/DD/YYYY',
	});
	
});
//Chossn select
$(".chosen-select").chosen({ width: '100%' })
$(".chosen-select.no-search").chosen({ disable_search_threshold: 10})


$(function () {
	$('.time').datetimepicker({	
		icons: {
			time: "mdi mdi-clock",
			date: "mdi mdi-calendar",
			up: "mdi mdi-chevron-up",
			down: "mdi mdi-chevron-down",
			right:"mdi mdi-chevron-right",
			left:"mdi mdi-chevron-left"
		},
		format: 'LT'
	});
});

